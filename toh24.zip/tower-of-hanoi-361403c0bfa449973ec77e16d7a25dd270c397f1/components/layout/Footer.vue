<template>
  <footer class="p-4 text-right bg-gray-200">
    <p>
      &copy; Solomon |
      <a class="text-blue-700 visited:text-purple-700 hover:text-indigo-500 underline" href="https://github.com/Count-Monte/tower-of-hanoi">Source code</a>
    </p>
  </footer>
</template>
<template>
  <header class="border-blue-200 pb-2 mb-2">
    <h1 class="bg-blue-200 p-1 text-3xl p-4 mb-2">Tower of Hanoi</h1>
  </header>
</template>

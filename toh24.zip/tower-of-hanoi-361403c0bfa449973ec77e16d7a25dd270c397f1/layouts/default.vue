<template>
  <div>
    <LayoutHeader />
    <Nuxt />
    <LayoutFooter />
  </div>
</template>